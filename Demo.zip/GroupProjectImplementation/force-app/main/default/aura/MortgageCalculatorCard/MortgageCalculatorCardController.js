({
	myAction : function() {

	}
})